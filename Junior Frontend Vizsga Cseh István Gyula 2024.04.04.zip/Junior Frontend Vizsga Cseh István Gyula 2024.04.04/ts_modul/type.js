function PhErtek(vizsgaltErtek) {
    if (vizsgaltErtek === 7) {
        return "semleges";
    }
    else if (vizsgaltErtek < 7) {
        return "savas";
    }
    else {
        return "lúgos";
    }
}
function PrimekSzama(vizsgaltTomb) {
    var primekSzama = 0;
    for (var i = 0; i < vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i] > 1) {
            var isPrime = true;
            for (var j = 2; j <= Math.sqrt(vizsgaltTomb[i]); j++) {
                if (vizsgaltTomb[i] % j === 0) {
                    isPrime = false;
                    break;
                }
            }
            if (isPrime) {
                primekSzama++;
            }
        }
    }
    return primekSzama;
}
function MaganHangzokSzama(vizsgaltSzoveg) {
    var maganhangzok = ['a', 'á', 'e', 'é', 'i', 'í', 'o', 'ó', 'ö', 'ő', 'u', 'ú', 'ü', 'ű'];
    var maganhangzokSzama = 0;
    for (var i = 0; i < vizsgaltSzoveg.length; i++) {
        if (maganhangzok.includes(vizsgaltSzoveg[i].toLowerCase())) {
            maganhangzokSzama++;
        }
    }
    return maganhangzokSzama;
}
