import { Component } from '@angular/core';

@Component({
  selector: 'app-feladat',
  standalone: true,
  imports: [],
  templateUrl: './feladat.component.html',
  styleUrl: './feladat.component.css'
})
export class FeladatComponent {

}
